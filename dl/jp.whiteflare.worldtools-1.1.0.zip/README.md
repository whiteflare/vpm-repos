﻿# Flare's World Tools

VRChat SDK を想定した Unity 拡張エディタのパックです。

# see
https://esa-pages.io/p/sharing/15655/posts/77/10ba7fa9b233b41a1581.html

# credits
whiteflare

# license
MIT License (see LICENSE.txt)
