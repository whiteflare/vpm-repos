------------------------------
Lightmap ControlPanel
------------------------------

# これは何ですか？

UnityEditor で開いているシーン内の、ライトマップに関係するメッシュを一覧表示し、一括変更することのできるエディタ拡張です。

# 使い方

メニューの `Tools` → `whiteflare` → `Lightmap ControlPanel` からウィンドウを開くことが出来ます。

# 著作権とライセンスは何ですか？

MIT LICENSE での公開です。LICENSE.txt もご確認ください。
Copyright (C) 2021-2022 whiteflare

