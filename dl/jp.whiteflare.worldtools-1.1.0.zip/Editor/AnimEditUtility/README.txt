------------------------------
Anim Edit Utility
------------------------------

# これは何ですか？

Unity の AnimationController や VRCSDK3 の VRCExpressionParameters などを編集するユーティリティです。

# 何ができますか？

- 新規レイヤーの作成 → Parameters登録 → Menu登録
- 既存レイヤーのコピー
- その他の小さなユーティリティ

# 著作権とライセンスは何ですか？

MIT LICENSE での公開です。LICENSE.txt もご確認ください。
Copyright (C) 2021-2022 whiteflare
