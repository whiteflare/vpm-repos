------------------------------
Avatar Texture Tool
------------------------------

# これは何ですか？

VRChat のアバターが使用しているテクスチャのVRAMサイズを計測・一覧化し、設定を調整するためのツールです。

# 使い方

メニューの `Tools` → `whiteflare` → `Avatar Texture Tool` からウィンドウを開くことが出来ます。

# 著作権とライセンスは何ですか？

MIT LICENSE での公開です。LICENSE.txt もご確認ください。
Copyright (C) 2023 whiteflare
